-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2015 at 02:04 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `stagiaire`
--

-- --------------------------------------------------------

--
-- Table structure for table `ajout`
--

CREATE TABLE IF NOT EXISTS `ajout` (
  `CINStagiaire` char(8) NOT NULL,
  `nomStagiaire` varchar(20) NOT NULL,
  `prenomStagiaire` varchar(20) NOT NULL,
  `naissanceStagiaire` char(10) NOT NULL,
  `universiteStagiaire` varchar(30) NOT NULL,
  `specialtyStagiaire` varchar(30) NOT NULL,
  PRIMARY KEY (`CINStagiaire`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ajout`
--

INSERT INTO `ajout` (`CINStagiaire`, `nomStagiaire`, `prenomStagiaire`, `naissanceStagiaire`, `universiteStagiaire`, `specialtyStagiaire`) VALUES
('12634569', 'Ali', 'BenAli', '01/01/1992', 'ISETK', 'DSI21');

-- --------------------------------------------------------

--
-- Table structure for table `personnel`
--

CREATE TABLE IF NOT EXISTS `personnel` (
  `Nom` varchar(20) NOT NULL,
  `Prenom` varchar(20) NOT NULL,
  `Poste` varchar(30) NOT NULL,
  `login` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`login`,`password`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personnel`
--

INSERT INTO `personnel` (`Nom`, `Prenom`, `Poste`, `login`, `password`) VALUES
('Ahmed', 'BenAhmed', 'Technicien Reseau', 'ahmed', 'ahmedReseau');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
