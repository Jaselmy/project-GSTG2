Gestion des stagiaires----------------------
Url     : http://codes-sources.commentcamarche.net/source/100929-gestion-des-stagiairesAuteur  : tlili_soufDate    : 19/07/2020
Licence :
=========

Ce document intitul� � Gestion des stagiaires � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Salut,durant mon stage au sein de la société Poste Tunisienne,
<br />je propo
se comme application &quot;gestion des stagiaires&quot;
<br />dont a quatres t�
�ches principales:
<br />ajouter,rechercher,modifier,supprimer un stagiaire.
<
br /><pre class="code" data-mode="java">
package dataBase; 

import java.sql.Con
nection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sq
l.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTab
leModel;

public class Gestion_DB_Stagiaire {
 String query;
 Statement statemen
t;
 ResultSet rset;
 Connection connexion;
 public Gestion_DB_Stagiaire(){
  DB_
Connection.connect();
  connexion=DB_Connection.getConnexion();
  rset=null;
 }

 public DefaultTableModel rechercher(String entree){
  
  DefaultTableModel dt =
 new DefaultTableModel();
  
  try{
   dt.addColumn("CIN");
   dt.addColumn("Nom
");
   dt.addColumn("Prenom");
   dt.addColumn("Date naissance");
   dt.addColum
n("Université");
   dt.addColumn("Specialité");
   String[] tab=entree.split("
 ");
   statement=connexion.createStatement();
   
   for(int i=0,longeur=tab.le
ngth;i&lt;longeur;i++){
    query="SELECT * FROM ajout WHERE CINStagiaire='"+tab
[i]+"' OR nomStagiaire='"+tab[i]+"' OR prenomStagiaire='"+tab[i]+"'";
    rset=s
tatement.executeQuery(query);
   }
   
   while(rset.next()){
    Object []table
au={rset.getString("CINStagiaire"),rset.getString("nomStagiaire"),rset.getString
("prenomStagiaire"),
      rset.getString("naissanceStagiaire"),rset.getString("
universiteStagiaire"),rset.getString("specialtyStagiaire")};
    dt.addRow(table
au);
    
    
   }
   
   
  }
  
  catch(SQLException ex){
   ex.printStackTra
ce();
   JOptionPane.showMessageDialog(null,"Not Found","Message d?avertissement
",JOptionPane.ERROR_MESSAGE);
   
  }
  
  return dt;
 }
 public void ajouterSta
giaire(String cin,String nom,String prenom,String naissance,String universite,St
ring specialty){
  try{
   statement=connexion.createStatement();
   query="INSE
RT INTO ajout  VALUES('"+cin+"','"+nom+"','"+prenom+"','"+naissance+"','"+univer
site+"','"+specialty+"')";
   statement.executeUpdate(query);
   JOptionPane.sho
wMessageDialog(null,"Successfull Add","Message d?avertissement",JOptionPane.INFO
RMATION_MESSAGE);
  }
  catch(SQLException ex){
   ex.printStackTrace();
   JOpt
ionPane.showMessageDialog(null,"ERROR ADD INTO DB","Message d?avertissement",JOp
tionPane.ERROR_MESSAGE);
   
  }
 }
 public void supprimerStagiaire(String cin){

  try{
   
   statement=connexion.createStatement();
   query="DELETE FROM ajou
t WHERE CINStagiaire='"+cin+"'";
   statement.executeUpdate(query);
   JOptionPa
ne.showMessageDialog(null,"Successfull DELETE","Message d?avertissement",JOption
Pane.INFORMATION_MESSAGE);
  }
  catch(SQLException ex){
   ex.printStackTrace()
;
   JOptionPane.showMessageDialog(null,"ERROR","Message d?avertissement",JOptio
nPane.ERROR_MESSAGE);
   
  }
 }
 public void modifierStagiaire(String[] contenu
){
  try{
   
   statement=connexion.createStatement();
   query="UPDATE ajout S
ET nomStagiaire='"+contenu[1]+"',prenomStagiaire='"+contenu[2]+"' ,naissanceStag
iaire='"+contenu[3]+"',universiteStagiaire='"+contenu[4]+"',specialtyStagiaire='
"+contenu[5]+"'WHERE CINStagiaire='"+contenu[0]+"'";
   statement.executeUpdate(
query);
   JOptionPane.showMessageDialog(null,"Successfull ALTER","Message d?ave
rtissement",JOptionPane.INFORMATION_MESSAGE);
  }
  catch(SQLException ex){
   e
x.printStackTrace();
   JOptionPane.showMessageDialog(null,"ERROR","Message d?av
ertissement",JOptionPane.ERROR_MESSAGE);
   
  }
 }
 
 
 public boolean verifier
(String login,String password){
  boolean test=false;
  String log = null,pass=n
ull;
  try{
   statement=connexion.createStatement();
   query="SELECT login,pas
sword FROM personnel";
   rset=statement.executeQuery(query);
   while(rset.next
()|| (test==true)){
    log=rset.getString("login");
    pass=rset.getString("pa
ssword");
    if(log.equals(login) && pass.equals(password))
     test=true;  
 
  }
  }
  catch(SQLException ex){
   
  }
  return test;

 }
 
}
</pre>
<br />

<br />
